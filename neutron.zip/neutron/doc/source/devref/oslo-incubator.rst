oslo-incubator
==============

A number of modules used are from the oslo-incubator project. Imported modules
that are directly used by Neutron are listed in openstack-common.conf.

More information can be found in `the corresponding policy
<http://specs.openstack.org/openstack/oslo-specs/specs/policy/incubator.html>`_.
