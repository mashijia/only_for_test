# Copyright 2013 VMware, Inc.  All rights reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import webob.exc

from neutron.api import extensions
from neutron.api.v2 import attributes as attr
from neutron.api.v2 import resource_helper
from neutron.common import exceptions as nexception
from oslo_config import cfg

vip_opts = [
    #TODO(limao): use quota framework when it support quota for attributes
    cfg.IntOpt('max_allowed_vip', default=10,
               help=_("Maximum number of vips")),
]

cfg.CONF.register_opts(vip_opts)


class VIPsMissingIP(nexception.InvalidInput):
    message = _("VIP must contain ip_address")


class VIPAndPortSecurityRequired(nexception.Conflict):
    message = _("Port Security must be enabled in order to have vip on a "
                "port.")


class VIPInUse(nexception.Conflict):
    message = _("The VIP is associated with a fixed port, can't be deleted now"
                ". Please disassociate it first.")


class DuplicateVIPInRequest(nexception.InvalidInput):
    message = _("Request contains duplicate vip: "
                "mac_address %(mac_address)s ip_address %(ip_address)s.")


class VIPExhausted(nexception.BadRequest):
    message = _("The number of vip "
                "exceeds the maximum %(quota)s.")


def _validate_VIPs(address_pairs, valid_values=None):
    unique_check = {}
    if len(address_pairs) > cfg.CONF.max_allowed_address_pair:
        raise VIPExhausted(
            quota=cfg.CONF.max_allowed_address_pair)

    for address_pair in address_pairs:
        # mac_address is optional, if not set we use the mac on the port
        if 'mac_address' in address_pair:
            msg = attr._validate_mac_address(address_pair['mac_address'])
            if msg:
                raise webob.exc.HTTPBadRequest(msg)
        if 'ip_address' not in address_pair:
            raise VIPsMissingIP()

        mac = address_pair.get('mac_address')
        ip_address = address_pair['ip_address']
        if (mac, ip_address) not in unique_check:
            unique_check[(mac, ip_address)] = None
        else:
            raise DuplicateVIPInRequest(mac_address=mac,
                                        ip_address=ip_address)

        invalid_attrs = set(address_pair.keys()) - set(['mac_address',
                                                        'ip_address'])
        if invalid_attrs:
            msg = (_("Unrecognized attribute(s) '%s'") %
                   ', '.join(set(address_pair.keys()) -
                             set(['mac_address', 'ip_address'])))
            raise webob.exc.HTTPBadRequest(msg)

        if '/' in ip_address:
            msg = attr._validate_subnet(ip_address)
        else:
            msg = attr._validate_ip_address(ip_address)
        if msg:
            raise webob.exc.HTTPBadRequest(msg)

attr.validators['type:validate_VIPs'] = (
    _validate_VIPs)

VIPS = 'vips'
ADDRESS_PAIRS = 'allowed_address_pairs'
ASSOCIATED_FIXED_PORTS = 'associated_fixed_ports'
EXTENDED_ATTRIBUTES_2_0 = {
    VIPS: {
        'id': {'allow_post': False, 'allow_put': False,
               'validate': {'type:uuid': None},
               'is_visible': True,
               'primary_key': True},
        'name': {'allow_post': True, 'allow_put': True, 'default': '',
                 'validate': {'type:string': attr.NAME_MAX_LEN},
                 'is_visible': True},
        'network_id': {'allow_post': True, 'allow_put': False,
                       'required_by_policy': True,
                       'validate': {'type:uuid': None},
                       'is_visible': True},
        'admin_state_up': {'allow_post': True, 'allow_put': True,
                           'default': True,
                           'convert_to': attr.convert_to_boolean,
                           'is_visible': True},
        'mac_address': {'allow_post': True, 'allow_put': True,
                        'default': attr.ATTR_NOT_SPECIFIED,
                        'validate': {'type:mac_address': None},
                        'enforce_policy': True,
                        'is_visible': True},
        'fixed_ips': {'allow_post': True, 'allow_put': True,
                      'default': attr.ATTR_NOT_SPECIFIED,
                      'convert_list_to': attr.convert_kvp_list_to_dict,
                      'validate': {'type:fixed_ips': None},
                      'enforce_policy': True,
                      'is_visible': True},
        'device_id': {'allow_post': True, 'allow_put': True,
                      'validate': {'type:string': attr.DEVICE_ID_MAX_LEN},
                      'default': '',
                      'is_visible': True},
        'device_owner': {'allow_post': True, 'allow_put': True,
                         'validate':
                             {'type:string': attr.DEVICE_OWNER_MAX_LEN},
                         'default': '',
                         'is_visible': True},
        'tenant_id': {'allow_post': True, 'allow_put': False,
                      'validate': {'type:string': attr.TENANT_ID_MAX_LEN},
                      'required_by_policy': True,
                      'is_visible': True},
        'status': {'allow_post': False, 'allow_put': False,
                   'is_visible': True},
        ASSOCIATED_FIXED_PORTS: {'allow_post': True, 'allow_put': True,
                                 'validate': {'type:uuid_list': None},
                                 'enforce_policy': True,
                                 'default': attr.ATTR_NOT_SPECIFIED,
                                 'is_visible': True}
    }
}


class Vips(extensions.ExtensionDescriptor):
    """Extension class supporting vips."""

    @classmethod
    def get_name(cls):
        return "Vips"

    @classmethod
    def get_alias(cls):
        return "vips"

    @classmethod
    def get_description(cls):
        return "Provides virtual IPs"

    @classmethod
    def get_namespace(cls):
        return "http://docs.openstack.org/ext/vips/api/v2.0"

    @classmethod
    def get_updated(cls):
        return "2013-07-23T10:00:00-00:00"

    def get_extended_resources(self, version):
        if version == "2.0":
            attr.PLURALS.update({'vips':
                                 'vip'})
            return EXTENDED_ATTRIBUTES_2_0
        else:
            return {}

    @classmethod
    def get_resources(cls):
        """Returns Ext Resources."""
        plural_mappings = resource_helper.build_plural_mappings(
            {}, EXTENDED_ATTRIBUTES_2_0)
        plural_mappings['vips'] = 'vip'
        attr.PLURALS.update(plural_mappings)
        return resource_helper.build_resource_info(plural_mappings,
                                                   EXTENDED_ATTRIBUTES_2_0,
                                                   None,
                                                   action_map=None,
                                                   register_quota=True)

    def update_attributes_map(self, attributes):
        super(Vips, self).update_attributes_map(
            attributes, extension_attrs_map=EXTENDED_ATTRIBUTES_2_0)
