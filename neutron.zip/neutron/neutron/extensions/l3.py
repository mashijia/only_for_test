# Copyright 2012 VMware, Inc.
# All rights reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

import abc

from oslo_config import cfg

from neutron.api import extensions
from neutron.api.v2 import attributes as attr
from neutron.api.v2 import resource_helper
from neutron.common import exceptions as nexception
from neutron.plugins.common import constants


class AreaNotFound(nexception.NotFound):
    message = _("Area %(id)s does not exists.")


class DuplicatedAreaName(nexception.InvalidInput):
    message = _("Area name %(name)s has already been used.")


class DuplicatedHostName(nexception.InvalidInput):
    message = _("Host %(name)s has already been used by area.")


class HostNameNotFound(nexception.NotFound):
    message = _("Host_name %(name)s does not exists.")


class AreaHostNotFound(nexception.NotFound):
    message = _("Area host %(id)s does not exists.")


class AreaHostInUse(nexception.NotFound):
    message = _("%(name)s is in use.")


# L3 Exceptions
class RouterNotFound(nexception.NotFound):
    message = _("Router %(router_id)s could not be found")


class RouterInUse(nexception.InUse):
    message = _("Router %(router_id)s %(reason)s")

    def __init__(self, **kwargs):
        if 'reason' not in kwargs:
            kwargs['reason'] = "still has ports"
        super(RouterInUse, self).__init__(**kwargs)


class RouterInterfaceNotFound(nexception.NotFound):
    message = _("Router %(router_id)s does not have "
                "an interface with id %(port_id)s")


class RouterInterfaceNotFoundForSubnet(nexception.NotFound):
    message = _("Router %(router_id)s has no interface "
                "on subnet %(subnet_id)s")


class RouterInterfaceInUseByFloatingIP(nexception.InUse):
    message = _("Router interface for subnet %(subnet_id)s on router "
                "%(router_id)s cannot be deleted, as it is required "
                "by one or more floating IPs.")


class FloatingIPNotFound(nexception.NotFound):
    message = _("Floating IP %(floatingip_id)s could not be found")


class ExternalGatewayForFloatingIPNotFound(nexception.NotFound):
    message = _("External network %(external_network_id)s is not reachable "
                "from subnet %(subnet_id)s.  Therefore, cannot associate "
                "Port %(port_id)s with a Floating IP.")


class FloatingIPPortAlreadyAssociated(nexception.InUse):
    message = _("Cannot associate floating IP %(floating_ip_address)s "
                "(%(fip_id)s) with port %(port_id)s "
                "using fixed IP %(fixed_ip)s, as that fixed IP already "
                "has a floating IP on external network %(net_id)s.")


class RouterExternalGatewayInUseByFloatingIp(nexception.InUse):
    message = _("Gateway cannot be updated for router %(router_id)s, since a "
                "gateway to external network %(net_id)s is required by one or "
                "more floating IPs.")


# Duplicated Outside Port Exceptions
class DuplicatedOutsidePort(nexception.InvalidInput):
    message = _("Outside port %(port)s has already been used.")


class InvalidInsideAddress(nexception.InvalidInput):
    message = _("inside address %(inside_addr)s does not match "
                "any subnets in this router.")


class RunOutOfOutsidePort(nexception.InvalidInput):
    message = _("The outside port is exhausted.")


class InconsistentPortWithFixedIP(nexception.InvalidInput):
    message = _("The Port id %(port_id)s and the fixed IP %(inside_addr)s "
                "don't match.")


class PortNotFound(nexception.InvalidInput):
    message = _("The Port id %(port_id)s not found.")


ROUTERS = 'routers'
EXTERNAL_GW_INFO = 'external_gateway_info'

RESOURCE_ATTRIBUTE_MAP = {
    ROUTERS: {
        'id': {'allow_post': False, 'allow_put': False,
               'validate': {'type:uuid': None},
               'is_visible': True,
               'primary_key': True},
        'name': {'allow_post': True, 'allow_put': True,
                 'validate': {'type:string': attr.NAME_MAX_LEN},
                 'is_visible': True, 'default': ''},
        'admin_state_up': {'allow_post': True, 'allow_put': True,
                           'default': True,
                           'convert_to': attr.convert_to_boolean,
                           'is_visible': True},
        'status': {'allow_post': False, 'allow_put': False,
                   'is_visible': True},
        'tenant_id': {'allow_post': True, 'allow_put': False,
                      'required_by_policy': True,
                      'validate': {'type:string': attr.TENANT_ID_MAX_LEN},
                      'is_visible': True},
        EXTERNAL_GW_INFO: {'allow_post': True, 'allow_put': True,
                           'is_visible': True, 'default': None,
                           'enforce_policy': True,
                           'validate': {
                               'type:dict_or_nodata': {
                                   'network_id': {'type:uuid': None,
                                                  'required': True},
                                   'external_fixed_ips': {
                                       'convert_list_to':
                                       attr.convert_kvp_list_to_dict,
                                       'type:fixed_ips': None,
                                       'default': None,
                                       'required': False,
                                   }
                               }
                           }}
    },
    'floatingips': {
        'id': {'allow_post': False, 'allow_put': False,
               'validate': {'type:uuid': None},
               'is_visible': True,
               'primary_key': True},
        'floating_ip_address': {'allow_post': True, 'allow_put': False,
                                'validate': {'type:ip_address_or_none': None},
                                'is_visible': True, 'default': None,
                                'enforce_policy': True},
        'floating_network_id': {'allow_post': True, 'allow_put': False,
                                'validate': {'type:uuid': None},
                                'is_visible': True},
        'router_id': {'allow_post': False, 'allow_put': False,
                      'validate': {'type:uuid_or_none': None},
                      'is_visible': True, 'default': None},
        'port_id': {'allow_post': True, 'allow_put': True,
                    'validate': {'type:uuid_or_none': None},
                    'is_visible': True, 'default': None,
                    'required_by_policy': True},
        'fixed_ip_address': {'allow_post': True, 'allow_put': True,
                             'validate': {'type:ip_address_or_none': None},
                             'is_visible': True, 'default': None},
        'tenant_id': {'allow_post': True, 'allow_put': False,
                      'required_by_policy': True,
                      'validate': {'type:string': attr.TENANT_ID_MAX_LEN},
                      'is_visible': True},
        'status': {'allow_post': False, 'allow_put': False,
                   'is_visible': True},
        'update_bl': {'allow_post': False, 'allow_put': True,
                      'is_visible': False},
        'max_up_kbps': {'allow_post': True, 'allow_put': True,
                        'is_visible': True,
                        'validate': {'type:range': [1, 10240000]},
                        'default': attr.ATTR_NOT_SPECIFIED},
        'max_down_kbps': {'allow_post': True, 'allow_put': True,
                          'is_visible': True,
                          'validate': {'type:range': [1, 10240000]},
                          'default': attr.ATTR_NOT_SPECIFIED},
        'tc_class_id': {'allow_post': False, 'allow_put': False,
                        'is_visible': True},
        'tc_mark_id': {'allow_post': False, 'allow_put': False,
                       'is_visible': True},
        'fixed_ips': {'allow_post': False, 'allow_put': False,
                      'is_visible': True}
    },
    'portforwardings': {
        'id': {'allow_post': False, 'allow_put': False,
               'validate': {'type:uuid': None},
               'is_visible': True,
               'primary_key': True},
        'name': {'allow_post': True, 'allow_put': True,
                 'validate': {'type:string': attr.NAME_MAX_LEN},
                 'is_visible': True, 'default': ''},
        'description': {'allow_post': True, 'allow_put': True,
                        'validate': {'type:string': attr.DESCRIPTION_MAX_LEN},
                        'is_visible': True, 'default': ''},
        'router_id': {'allow_post': True, 'allow_put': False,
                      'validate': {'type:uuid_or_none': None},
                      'is_visible': True, 'default': None},
        'tenant_id': {'allow_post': True, 'allow_put': False,
                      'validate': {'type:string': attr.TENANT_ID_MAX_LEN},
                      'is_visible': True},
        'outside_port': {'allow_post': False, 'allow_put': False,
                         'is_visible': True,
                         'validate': {'type:range': [1, 65535]},
                         'default': attr.ATTR_NOT_SPECIFIED},
        'inside_port': {'allow_post': True, 'allow_put': True,
                        'is_visible': True,
                        'validate': {'type:range': [1, 65535]},
                        'default': attr.ATTR_NOT_SPECIFIED},
        'inside_addr': {'allow_post': True, 'allow_put': True,
                        'validate': {'type:ip_address_or_none': None},
                        'is_visible': True, 'default': None},
        'protocol': {'allow_post': True, 'allow_put': False,
                     'validate': {'type:values': ['TCP', 'UDP']},
                     'is_visible': True},
        'status': {'allow_post': False, 'allow_put': False,
                   'is_visible': True},
        'fixed_port_id': {'allow_post': True, 'allow_put': True,
                          'validate': {'type:uuid_or_none': None},
                          'is_visible': True,
                          'required_by_policy': True},
        'fixed_ips': {'allow_post': False, 'allow_put': False,
                      'is_visible': True},
        'created_at': {'allow_post': False, 'allow_put': False,
                       'is_visible': True},
    },
    'areas': {
        'id': {'allow_post': False, 'allow_put': False,
               'validate': {'type:uuid': None},
               'is_visible': True,
               'primary_key': True},
        'name': {'allow_post': True, 'allow_put': True, 'default': '',
                 'validate': {'type:string': attr.NAME_MAX_LEN},
                 'is_visible': True},
        'description': {'allow_post': True, 'allow_put': True,
                        'validate': {'type:string': attr.DESCRIPTION_MAX_LEN},
                        'is_visible': True, 'default': ''},
        'created_at': {'allow_post': False, 'allow_put': False,
                       'is_visible': True},
        'tenant_id': {'allow_post': True, 'allow_put': False,
                      'validate': {'type:string': None},
                      'required_by_policy': True,
                      'is_visible': True},
        'host_name': {'allow_post': True, 'allow_put': False, 'default': '',
                      'validate': {'type:string': attr.NAME_MAX_LEN},
                      'is_visible': True},
    },
    'area_hosts': {
        'id': {'allow_post': False, 'allow_put': False,
               'validate': {'type:uuid': None},
               'is_visible': True,
               'primary_key': True},
        'area_id': {'allow_post': True, 'allow_put': False,
                    'validate': {'type:uuid': None},
                    'is_visible': True},
        'host_name': {'allow_post': True, 'allow_put': False, 'default': '',
                      'validate': {'type:string': attr.NAME_MAX_LEN},
                      'is_visible': True},
        'tenant_id': {'allow_post': True, 'allow_put': False,
                      'validate': {'type:string': None},
                      'required_by_policy': True,
                      'is_visible': True},
    },
    'network_nodes': {
        'host_name': {'allow_post': True, 'allow_put': False, 'default': '',
                      'validate': {'type:string': attr.NAME_MAX_LEN},
                      'is_visible': True},
    },
    'area_host_lists': {
        'host_name': {'allow_post': True, 'allow_put': False, 'default': '',
                      'validate': {'type:string': attr.NAME_MAX_LEN},
                      'is_visible': True},
    },
    'avail_network_nodes': {
        'host_name': {'allow_post': True, 'allow_put': False, 'default': '',
                      'validate': {'type:string': attr.NAME_MAX_LEN},
                      'is_visible': True},
    },
}

l3_quota_opts = [
    cfg.IntOpt('quota_router',
               default=10,
               help=_('Number of routers allowed per tenant. '
                      'A negative value means unlimited.')),
    cfg.IntOpt('quota_floatingip',
               default=50,
               help=_('Number of floating IPs allowed per tenant. '
                      'A negative value means unlimited.')),
    cfg.IntOpt('quota_portforwarding',
               default=50,
               help=_('Number of portforwardings allowed per tenant. '
                      'A negative value means unlimited.')),
    cfg.IntOpt('quota_area',
               default=50,
               help=_('Number of area allowed for admin. '
                      'A negative value means unlimited.')),
    cfg.IntOpt('quota_area_host',
               default=50,
               help=_('Number of area host allowed for admin. '
                      'A negative value means unlimited.')),
]
cfg.CONF.register_opts(l3_quota_opts, 'QUOTAS')


class L3(extensions.ExtensionDescriptor):

    @classmethod
    def get_name(cls):
        return "Neutron L3 Router"

    @classmethod
    def get_alias(cls):
        return "router"

    @classmethod
    def get_description(cls):
        return ("Router abstraction for basic L3 forwarding"
                " between L2 Neutron networks and access to external"
                " networks via a NAT gateway.")

    @classmethod
    def get_namespace(cls):
        return "http://docs.openstack.org/ext/neutron/router/api/v1.0"

    @classmethod
    def get_updated(cls):
        return "2012-07-20T10:00:00-00:00"

    @classmethod
    def get_resources(cls):
        """Returns Ext Resources."""
        plural_mappings = resource_helper.build_plural_mappings(
            {}, RESOURCE_ATTRIBUTE_MAP)
        plural_mappings['external_fixed_ips'] = 'external_fixed_ip'
        attr.PLURALS.update(plural_mappings)
        action_map = {'router': {'add_router_interface': 'PUT',
                                 'remove_router_interface': 'PUT'}}
        return resource_helper.build_resource_info(plural_mappings,
                                                   RESOURCE_ATTRIBUTE_MAP,
                                                   constants.L3_ROUTER_NAT,
                                                   action_map=action_map,
                                                   register_quota=True)

    def update_attributes_map(self, attributes):
        super(L3, self).update_attributes_map(
            attributes, extension_attrs_map=RESOURCE_ATTRIBUTE_MAP)

    def get_extended_resources(self, version):
        if version == "2.0":
            return RESOURCE_ATTRIBUTE_MAP
        else:
            return {}


class RouterPluginBase(object):

    @abc.abstractmethod
    def create_router(self, context, router):
        pass

    @abc.abstractmethod
    def update_router(self, context, id, router):
        pass

    @abc.abstractmethod
    def get_router(self, context, id, fields=None):
        pass

    @abc.abstractmethod
    def delete_router(self, context, id):
        pass

    @abc.abstractmethod
    def get_routers(self, context, filters=None, fields=None,
                    sorts=None, limit=None, marker=None, page_reverse=False):
        pass

    @abc.abstractmethod
    def add_router_interface(self, context, router_id, interface_info):
        pass

    @abc.abstractmethod
    def remove_router_interface(self, context, router_id, interface_info):
        pass

    @abc.abstractmethod
    def create_floatingip(self, context, floatingip):
        pass

    @abc.abstractmethod
    def update_floatingip(self, context, id, floatingip):
        pass

    @abc.abstractmethod
    def get_floatingip(self, context, id, fields=None):
        pass

    @abc.abstractmethod
    def delete_floatingip(self, context, id):
        pass

    @abc.abstractmethod
    def get_floatingips(self, context, filters=None, fields=None,
                        sorts=None, limit=None, marker=None,
                        page_reverse=False):
        pass

    def get_routers_count(self, context, filters=None):
        raise NotImplementedError()

    def get_floatingips_count(self, context, filters=None):
        raise NotImplementedError()

    @abc.abstractmethod
    def create_portforwarding(self, context, portforwarding):
        pass

    @abc.abstractmethod
    def get_portforwarding(self, context, id, fields=None):
        pass

    @abc.abstractmethod
    def delete_portforwarding(self, context, id):
        pass

    @abc.abstractmethod
    def get_portforwardings(self, context, filters=None, fields=None,
                        sorts=None, limit=None, marker=None,
                        page_reverse=False):
        pass

    @abc.abstractmethod
    def create_area(self, context, area):
        pass

    @abc.abstractmethod
    def update_area(self, context, id, area):
        pass

    @abc.abstractmethod
    def delete_area(self, context, id):
        pass

    @abc.abstractmethod
    def get_areas(self, context, filters=None, fields=None,
                  sorts=None, limit=None, marker=None,
                  page_reverse=False):
        pass

    @abc.abstractmethod
    def get_area(self, context, id, fields=None):
        pass

    @abc.abstractmethod
    def create_area_host(self, context, area_host):
        pass

    @abc.abstractmethod
    def update_area_host(self, context, id, area_host):
        pass

    @abc.abstractmethod
    def delete_area_host(self, context, id):
        pass

    @abc.abstractmethod
    def get_area_hosts(self, context, filters=None, fields=None,
                       sorts=None, limit=None, marker=None,
                       page_reverse=False):
        pass

    @abc.abstractmethod
    def get_area_host(self, context, id, fields=None):
        pass

    @abc.abstractmethod
    def get_area_host_list(self, context, id, fields=None):
        pass

    @abc.abstractmethod
    def get_network_nodes(self, context, filters=None, fields=None,
                          sorts=None, limit=None, marker=None,
                          page_reverse=False):
        pass

    def avail_network_nodes(self, context, filters=None, fields=None,
                            sorts=None, limit=None, marker=None,
                            page_reverse=False):
        pass
