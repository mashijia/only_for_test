# Copyright 2011 OpenStack Foundation
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.
"""
Module dedicated functions/classes auditing the users operation logs.

"""

from neutron.i18n import _LE, _LI
from oslo_config import cfg
from oslo_log import log as logging
import oslo_messaging as messaging

import eventlet
import webob.dec

from neutron.common import rpc
from neutron import wsgi

audit_logs_opts = [
    cfg.StrOpt('audit_logs_topic',
               default='audit_logs',
               help='The topic to audit logs'),
]

LOG = logging.getLogger(__name__)

CONF = cfg.CONF
CONF.register_opts(audit_logs_opts)


class AuditLogsMiddleware(wsgi.Middleware):
    event_types = {
        ('POST', 'networks'): 'audit.neutron.network.create',
        ('DELETE', 'networks'): 'audit.neutron.network.delete',
        ('PUT', 'networks'): 'audit.neutron.network.update',
        ('POST', 'subnets'): 'audit.neutron.subnet.create',
        ('PUT', 'subnets'): 'audit.neutron.subnet.update',
        ('DELETE', 'subnets'): 'audit.neutron.subnet.delete',
        ('POST', 'ports'): 'audit.neutron.port.create',
        ('PUT', 'ports'): 'audit.neutron.port.update',
        ('DELETE', 'ports'): 'audit.neutron.port.delete',
        ('POST', 'security-groups'): 'audit.neutron.securityGroup.create',
        ('PUT', 'security-groups'): 'audit.neutron.securityGroup.update',
        ('DELETE', 'security-groups'): 'audit.neutron.securityGroup.delete',
        ('POST', 'security-group-rules'): 'audit.neutron.securityRule.create',
        ('DELETE', 'security-group-rules'):
            'audit.neutron.securityRule.delete',
        ('POST', 'routers'): 'audit.neutron.router.create',
        ('PUT', 'routers'): 'audit.neutron.router.update',
        ('DELETE', 'routers'): 'audit.neutron.router.delete',
        ('PUT', 'add_router_interface'): 'audit.neutron.router.interfaceAdd',
        ('PUT', 'remove_router_interface'):
            'audit.neutron.router.interfaceDelete',
        ('POST', 'floatingips'): 'audit.neutron.floating.create',
        ('PUT', 'floatingips'): 'audit.neutron.floating.update',
        ('DELETE', 'floatingips'): 'audit.neutron.floating.delete',
        ('POST', 'firewalls'): 'audit.neutron.firewall.create',
        ('PUT', 'firewalls'): 'audit.neutron.firewall.update',
        ('DELETE', 'firewalls'): 'audit.neutron.firewall.delete',
        ('POST', 'firewall_policies'): 'audit.neutron.firewallPolicy.create',
        ('PUT', 'firewall_policies'): 'audit.neutron.firewallPolicy.update',
        ('DELETE', 'firewall_policies'):
            'audit.neutron.firewallPolicy.delete',
        ('POST', 'firewall_rules'): 'audit.neutron.firewallRule.create',
        ('DELETE', 'firewall_rules'): 'audit.neutron.firewallRule.delete',
        ('POST', 'lb', 'pools'): 'audit.neutron.lbPool.create',
        ('PUT', 'lb', 'pools'): 'audit.neutron.lbPool.update',
        ('DELETE', 'lb', 'pools'): 'audit.neutron.lbPool.delete',
        ('POST', 'lb', 'vips'): 'audit.neutron.lbVip.create',
        ('PUT', 'lb', 'vips'): 'audit.neutron.lbVip.update',
        ('DELETE', 'lb', 'vips'): 'audit.neutron.lbVip.delete',
        ('POST', 'lb', 'members'): 'audit.neutron.lbMember.create',
        ('PUT', 'lb', 'members'): 'audit.neutron.lbMember.update',
        ('DELETE', 'lb', 'members'): 'audit.neutron.lbMember.delete',
        ('POST', 'lb', 'health_monitors'): 'audit.neutron.lbMonitor.create',
        ('PUT', 'lb', 'health_monitors'): 'audit.neutron.lbMonitor.update',
        ('DELETE', 'lb', 'health_monitors'):
            'audit.neutron.lbMonitor.delete',
        ('POST', 'lb', 'pools', 'health_monitors'):
            'audit.neutron.lbMonitor.associate',
        ('DELETE', 'lb', 'pools', 'health_monitors'):
            'audit.neutron.lbMonitor.disassociate',
        ('POST', 'vpnservices'): 'audit.neutron.vpnService.create',
        ('PUT', 'vpnservices'): 'audit.neutron.vpnService.update',
        ('DELETE', 'vpnservices'): 'audit.neutron.vpnService.delete',
        ('POST', 'ikepolicies'): 'audit.neutron.ikePolicy.create',
        ('PUT', 'ikepolicies'): 'audit.neutron.ikePolicy.update',
        ('DELETE', 'ikepolicies'): 'audit.neutron.ikePolicy.delete',
        ('POST', 'ipsecpolicies'): 'audit.neutron.ipsecPolicy.create',
        ('PUT', 'ipsecpolicies'): 'audit.neutron.ipsecPolicy.update',
        ('DELETE', 'ipsecpolicies'): 'audit.neutron.ipsecPolicy.delete',
        ('POST', 'areas'): 'audit.neutron.area.create',
        ('PUT', 'areas'): 'audit.neutron.area.update',
        ('DELETE', 'areas'): 'audit.neutron.area.delete',
        ('POST', 'area_hosts'): 'audit.neutron.areaHost.create',
        ('DELETE', 'area_hosts'): 'audit.neutron.areaHost.delete',
        ('POST', 'ipsec-site-connections'):
            'audit.neutron.ipsecConnection.create',
        ('PUT', 'ipsec-site-connections'):
            'audit.neutron.ipsecConnection.update',
        ('DELETE', 'ipsec-site-connections'):
            'audit.neutron.ipsecConnection.delete',
        ('POST', 'portforwardings'):
            'audit.neutron.portForwarding.create',
        ('DELETE', 'portforwardings'):
            'audit.neutron.portForwarding.delete',
        ('PUT', 'quotas', 'network'):
            'audit.compute.quota.updateNetwork',
        ('PUT', 'quotas', 'subnet'):
            'audit.compute.quota.updateSubnet',
        ('PUT', 'quotas', 'floatingip'):
            'audit.compute.quota.updateFloatingip',
        ('PUT', 'quotas', 'router'):
            'audit.compute.quota.updateRouter',
        ('PUT', 'quotas', 'pool'):
            'audit.compute.quota.updatePool',
        ('PUT', 'quotas', 'portforwarding'):
            'audit.compute.quota.updatePortforwarding',
        ('PUT', 'quotas', 'security_group'):
            'audit.compute.quota.updateSgroup',
        ('POST', 'lbaas', 'loadbalancers'):
            'audit.neutron.loadbalancer.create',
        ('PUT', 'lbaas', 'loadbalancers'):
            'audit.neutron.loadbalancer.update',
        ('DELETE', 'lbaas', 'loadbalancers'):
            'audit.neutron.loadbalancer.delete',
        ('POST', 'lbaas', 'listeners'): 'audit.neutron.loadListener.create',
        ('PUT', 'lbaas', 'listeners'): 'audit.neutron.loadListener.update',
        ('DELETE', 'lbaas', 'listeners'):
            'audit.neutron.loadListener.delete',
        ('POST', 'lbaas', 'pools'): 'audit.neutron.loadPool.create',
        ('PUT', 'lbaas', 'pools'): 'audit.neutron.loadPool.update',
        ('DELETE', 'lbaas', 'pools'): 'audit.neutron.loadPool.delete',
        ('POST', 'lbaas', 'members'): 'audit.neutron.loadMember.create',
        ('PUT', 'lbaas', 'members'): 'audit.neutron.loadMember.update',
        ('DELETE', 'lbaas', 'members'): 'audit.neutron.loadMember.delete',
        ('POST', 'lbaas', 'healthmonitors'):
            'audit.neutron.loadMonitor.create',
        ('PUT', 'lbaas', 'healthmonitors'):
            'audit.neutron.loadMonitor.update',
        ('DELETE', 'lbaas', 'healthmonitors'):
            'audit.neutron.loadMonitor.delete',
        ('DELETE', 'vips'): 'audit.neutron.vips.delete',
        ('POST', 'vips'): 'audit.neutron.vips.create',
        ('PUT', 'vips'): 'audit.neutron.vips.updateVips'
    }

    def __init__(self, application, **kwargs):
        super(AuditLogsMiddleware, self).__init__(application)

    @webob.dec.wsgify(RequestClass=wsgi.Request)
    def __call__(self, req):
        response = req.get_response(self.application)
        response = self.process_response(response)

        message = self._make_audit_message(req, response)

        if message:
            def _inner_send_audit_message(*args, **kwargs):
                self._send_audit_message(*args, **kwargs)
            eventlet.spawn_n(_inner_send_audit_message, req, message)

        return response

    def _url_event_mapping(self, method, url, body):
        event_type = ''
        event_key = ''
        url = url.replace('.json', '')
        parts = url.split('/')
        if ('networks' in url or
            'subnets' in url or
            'ports' in url or
            'security-groups' in url or
            'security-group-rules' in url or
            'floatingips' in url or
            'portforwardings' in url or
            'areas' in url or
            'area_hosts' in url):
            event_key = (method, parts[4])
        elif ('routers' in url):
            if ('add_router_interface' in url or
                'remove_router_interface' in url):
                event_key = (method, parts[6])
            else:
                event_key = (method, parts[4])
        elif('quotas' in url and 'network' in body):
            event_key = (method, 'quotas', 'network')
        elif('quotas' in url and 'subnet' in body):
            event_key = (method, 'quotas', 'subnet')
        elif('quotas' in url and 'floatingip' in body):
            event_key = (method, 'quotas', 'floatingip')
        elif('quotas' in url and 'router' in body):
            event_key = (method, 'quotas', 'router')
        elif('quotas' in url and 'pool' in body):
            event_key = (method, 'quotas', 'pool')
        elif('quotas' in url and 'portforwarding' in body):
            event_key = (method, 'quotas', 'portforwarding')
        elif('quotas' in url and 'security_group' in body):
            event_key = (method, 'quotas', 'security_group')
        elif ('fw/' in url or
              'vpn/' in url):
            event_key = (method, parts[5])
        elif ('lb/vips' in url or
              'lb/members' in url or
              'lb/health_monitors' in url):
            event_key = (method, parts[4], parts[5])
        elif ('lb/pools' in url):
            if ('health_monitors' in url):
                event_key = (method, parts[4], parts[5], parts[7])
            else:
                event_key = (method, parts[4], parts[5])
        elif ('vips' in url and 'lb/vips' not in url):
            event_key = (method, 'vips')
        else:
            event_key = 'nonexistent_key'

        event_key = self._get_lbaas_event_key(method, url, event_key)

        if (event_key in self.event_types.keys()):
            event_type = self.event_types[event_key]
        else:
            event_type = 'unrecognized_type'
        return event_type

    def _get_lbaas_event_key(self, method, url, event_key):
        # if event_key has been assigned, return directly.
        if (event_key != '' and event_key != 'nonexistent_key'):
            return event_key
        # if lbaas not in url, return ''
        if ('lbaas' not in url):
            return event_key
        event_keys = ('loadbalancers', 'listeners', 'healthmonitors', 'pools')
        # members url contains pools, so need process it separately
        if ('members' in url):
            event_key = (method, 'lbaas', 'members')
        else:
            for key in event_keys:
                if (key in url):
                    event_key = (method, 'lbaas', key)
        return event_key

    def _make_audit_message(self, request, response):
        method = request.method
        if (method != 'GET'):
            url = request.url
            request_body = request.body
            event_type = self._url_event_mapping(method, url, request_body)
            status = response.status
            response_body = response.body
            message = {"event_type": event_type,
                       "request_url": url,
                       "request_method": method,
                       "request_body": request_body,
                       "response_body": response_body,
                       "status": status}
            return message
        return None

    def _send_audit_message(self, request, message):
        try:
            LOG.info(_LI("Begin to send audit log message."))
            target = messaging.Target(topic=CONF.audit_logs_topic,
                                      version='1.0')
            client = rpc.get_client(target)
            ctxt = request.environ.get("neutron.context")
            cctxt = client.prepare()
            cctxt.cast(ctxt, '_send_audit_message', message=message)
        except Exception as err:
            LOG.error(_LE("failed to send audit log message %s"), err)
