# Copyright 2012 OpenStack Foundation
# All Rights Reserved.
#
#    Licensed under the Apache License, Version 2.0 (the "License"); you may
#    not use this file except in compliance with the License. You may obtain
#    a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
#    WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
#    License for the specific language governing permissions and limitations
#    under the License.

from neutron.agent.common import config
from neutron.agent.linux import ip_lib
from neutron.agent.linux import utils
from neutron.common import constants as l3_constant
from oslo_log import log as logging

LOG = logging.getLogger(__name__)

# do not config rate limit if user has no rate config
DFAULT_RATE_KBPS = 0

MAX_INTERFACE_LIMIT_KBPS = 10 * 1024 * 1024

EXTERNAL_INGRESS_MARK = 0x2


class TCRuleCommand(object):

    def __init__(self):
        #
        self.root_helper = config.get_root_helper(utils.cfg.CONF)

    def _create_ratelimit_qdisc(self, ip_wrapper, ri, interface_name):
        LOG.debug("create ratelimit stuff for device %s", interface_name)
        default_class = 9
        # clear all previous egress qdisc, starting with a clean evvironment
        tc_cmd = ['tc', 'qdisc', 'del', 'dev', interface_name, 'root']
        ip_wrapper.netns.execute(tc_cmd, check_exit_code=False)
        # attach qdisc to interface
        tc_cmd = ['tc', 'qdisc', 'add', 'dev', interface_name,
                  'root', 'handle', '1:0', 'htb', 'default',
                  '%d' % default_class]
        ip_wrapper.netns.execute(tc_cmd, check_exit_code=True)
        interfaces = [interface_name]
        # add default class filter and leaf qdisc
        self._add_class_filter(ip_wrapper, default_class, interfaces,
                               MAX_INTERFACE_LIMIT_KBPS)

    def _check_root_htb_exist(self, ip_wrapper, interface_name):
        tc_cmd = ['tc', 'qdisc', 'show', 'dev', interface_name]
        ret = ip_wrapper.netns.execute(tc_cmd, check_exit_code=True)
        if ret:
            return True
        return False

    def process_tc_init(self, ri, external_interface):
        ip_wrapper = ip_lib.IPWrapper(namespace=ri.ns_name)
        self._create_ratelimit_qdisc(ip_wrapper, ri, external_interface)

    def _get_inner_interface_name(self, ri, fixed_subnet_id=None):
        inner_names = []
        # for external gateway, return all inner interface names
        if not fixed_subnet_id:
            for fixed_ip in ri.router.get(l3_constant.INTERFACE_KEY, []):
                inner_name = "qr-" + fixed_ip['id'][0:11]
                inner_names.append(inner_name)
            return inner_names
        for fixed_ip in ri.router.get(l3_constant.INTERFACE_KEY, []):
            if fixed_subnet_id == fixed_ip['subnets'][0]['id']:
                inner_name = "qr-" + fixed_ip['id'][0:11]
                inner_names = [inner_name]
                break
        return inner_names

    def _get_all_floating_ips(self, ri):
        fips = []
        for fip in ri.router.get(l3_constant.FLOATINGIP_KEY, []):
            fixed_subnet_id = fip['fixed_ips'][0]['subnet_id']
            inner_names = self._get_inner_interface_name(ri, fixed_subnet_id)
            fips.append({'floating_ip_address': fip['floating_ip_address'],
                         'rate_limit_up':
                             fip['max_up_kbps'] or DFAULT_RATE_KBPS,
                         'rate_limit_down':
                             fip['max_down_kbps'] or DFAULT_RATE_KBPS,
                         'tc_class_id': fip['tc_class_id'],
                         'tc_mark_id': fip['tc_mark_id'],
                         'inner_interfaces': inner_names,
                         'id': fip['id']})
        gw_port = ri.router.get("gw_port")
        ex_gw_info = ri.router.get("external_gateway_info")
        if gw_port and ex_gw_info:
            rate_limit_up = ex_gw_info.get('max_up_kbps') or DFAULT_RATE_KBPS
            rate_limit_down = ex_gw_info.get('max_down_kbps') or \
                DFAULT_RATE_KBPS
            tc_class_id = ex_gw_info.get('tc_class_id')
            tc_mark_id = ex_gw_info.get('tc_mark_id')
            if tc_class_id and tc_mark_id:
                fip_id = gw_port['device_id']
                fip_ip = gw_port['fixed_ips'][0]['ip_address']
                inner_names = self._get_inner_interface_name(ri)
                fips.append({'floating_ip_address': fip_ip,
                             'rate_limit_up': rate_limit_up,
                             'rate_limit_down': rate_limit_down,
                             'tc_class_id': tc_class_id,
                             'tc_mark_id': tc_mark_id,
                             'inner_interfaces': inner_names,
                             'id': fip_id})
        return fips

    def process_ratelimit(self, ri, external_interface):
        interfaces = [external_interface]
        avalialable_fips = set()
        ip_wrapper = ip_lib.IPWrapper(namespace=ri.ns_name)
        # check root htb exist
        if not self._check_root_htb_exist(ip_wrapper, external_interface):
            self._create_ratelimit_qdisc(ip_wrapper, ri, external_interface)
        # get all floating ips which need to be configed
        fips = self._get_all_floating_ips(ri)
        fip_class_rate_limit_dict = ri.fip_class_rate_limit_dict
        for fip in fips:
            fip_ip = fip['floating_ip_address']
            rate_limit_up = fip.get('rate_limit_up', 0)
            rate_limit_down = fip.get('rate_limit_down', 0)
            inner_interfaces = fip.get('inner_interfaces', [])
            # up or down, anyone is 0, just ignore it
            if rate_limit_up > 0 and rate_limit_down > 0:
                avalialable_fips.add(fip['id'])
                class_rate = fip_class_rate_limit_dict.get(fip['id'], {})
                if not class_rate:
                    class_rate['tc_class_id'] = fip['tc_class_id']
                    class_rate['tc_mark_id'] = fip['tc_mark_id']
                fip_class_rate_limit_dict[fip['id']] = class_rate
                tc_class_id = fip['tc_class_id']
                tc_mark_id = fip['tc_mark_id']
                old_rate_limit_up = class_rate.get('rate_limit_up', 0)
                old_rate_limit_down = class_rate.get('rate_limit_down', 0)
                old_inner_interfaces = class_rate.get('inner_interfaces', [])

                if old_rate_limit_up != rate_limit_up or \
                        old_rate_limit_down != rate_limit_down or\
                        set(old_inner_interfaces) != set(inner_interfaces):
                    self._add_class_filter(ip_wrapper, tc_class_id, interfaces,
                                           rate_limit_up, fip_ip=fip_ip,
                                           mark_id=tc_mark_id)
                    # add mark for floating ip down rate
                    self._add_mark_filter(ri, ip_wrapper, tc_class_id,
                                          tc_mark_id, rate_limit_down,
                                          inner_interfaces, fip_ip)
                    class_rate['rate_limit_up'] = rate_limit_up
                    class_rate['rate_limit_down'] = rate_limit_down
                    class_rate['inner_interfaces'] = inner_interfaces
                    class_rate['fip_ip'] = fip_ip
        deleted_ips = set(fip_class_rate_limit_dict.keys()) - \
            avalialable_fips
        LOG.debug("Deleted fixed ips %s", deleted_ips)
        for fip_id in deleted_ips:
            class_rate = fip_class_rate_limit_dict[fip_id]
            rate_limit_up = class_rate['rate_limit_up']
            rate_limit_down = class_rate['rate_limit_down']
            if rate_limit_up > 0 and rate_limit_down > 0:
                self._delete_class_filter(ip_wrapper,
                                          class_rate['tc_class_id'],
                                          interfaces, class_rate['fip_ip'],
                                          class_rate['tc_mark_id'])
                fip_class_rate_limit_dict.pop(fip_id, None)
                # remove mark for floating ip down rate
                self._delete_mark_filter(ip_wrapper,
                                         class_rate['tc_class_id'],
                                         class_rate['tc_mark_id'],
                                         class_rate['inner_interfaces'],
                                         class_rate['fip_ip'])
            else:
                LOG.debug("no tc config used, just ignore.")
        ri.fip_class_rate_limit_dict = fip_class_rate_limit_dict

    def _add_class_filter(self, ip_wrapper, minor_id, devs, rate_limit,
                          fip_ip=None, mark_id=None):
        for _int_name in devs:
            if not _int_name:
                continue
            burst = str(int(rate_limit) / 100)
            # add classed according to rate limit
            tc_cmd = ['tc', 'class', 'replace', 'dev', _int_name,
                      'parent', '1:', 'classid', '1:%d' % minor_id,
                      'htb', 'rate', '%skbit' % rate_limit,
                      'ceil', '%skbit' % rate_limit,
                      'burst', '%sk' % burst,
                      'cburst', '%sk' % burst,
                      'prio', '10']
            ip_wrapper.netns.execute(tc_cmd, check_exit_code=True)
            # add leaf sfq qdisc according
            tc_cmd = ['tc', 'qdisc', 'replace', 'dev', _int_name,
                      'parent', '1:%s' % minor_id, 'handle',
                      '%s' % minor_id, 'sfq']
            ip_wrapper.netns.execute(tc_cmd, check_exit_code=True)
            if fip_ip or mark_id:
                tc_cmd = self._get_replace_filter_cmd(_int_name, fip_ip,
                                                      minor_id, mark_id)
                ip_wrapper.netns.execute(tc_cmd, check_exit_code=True)

    def _get_replace_filter_cmd(self, interface, addr, minor, mark_id):
        srcflag = interface.startswith("qg-")
        # we use different prio so that we can delete it via prio
        # generate filter rule(s) for internal gateway interface
        if not srcflag:
            tc_cmd = ("tc filter replace dev %(interface)s parent 1:"
                      " protocol ip prio %(minor)d handle 0x%(mark_id)x/"
                      "%(mask)s fw classid 1:%(minor)d") % {
                "interface": interface,
                "minor": minor,
                "mark_id": mark_id << l3_constant.RATE_MARK_MASK_LONGTH,
                "mask": l3_constant.RATE_MARK_MASK}
            LOG.debug("_get_replace_filter_cmd: %s", tc_cmd)
            return tc_cmd.split()
        # generate filter rule(s) for external gateway interface
        tc_cmd = ("tc filter replace dev %(interface)s parent 1: protocol"
                  " ip prio %(minor)d u32 match ip %(src_dst)s %(addr)s/32"
                  " flowid 1:%(minor)d") % {"interface": interface,
                                    "src_dst": (srcflag and "src" or "dst"),
                                    "addr": addr,
                                    "minor": minor}
        LOG.debug("_get_replace_filter_cmd: %s", tc_cmd)
        return tc_cmd.split()

    def _get_delete_filter_cmd(self, interface, addr, minor, mark_id):
        srcflag = interface.startswith("qg-")
        # generate filter rule(s) for internal gateway interface
        if not srcflag:
            tc_cmd = ("tc filter delete dev %(interface)s parent 1:"
                      " protocol ip prio %(minor)d handle 0x%(mark_id)x/"
                      "%(mask)s fw classid 1:%(minor)d") % {
                "interface": interface,
                "minor": minor,
                "mark_id": mark_id << l3_constant.RATE_MARK_MASK_LONGTH,
                "mask": l3_constant.RATE_MARK_MASK}
            LOG.debug("_get_delete_filter_cmd: %s", tc_cmd)
            return tc_cmd.split()
        # generate filter rule(s) for external gateway interface
        tc_cmd = ("tc filter delete dev %(interface)s parent 1: protocol"
                  " ip prio %(minor)d u32 match ip %(src_dst)s %(addr)s/32"
                  " flowid 1:%(minor)d") % {"interface": interface,
                                    "src_dst": (srcflag and "src" or "dst"),
                                    "addr": addr,
                                    "minor": minor}
        LOG.debug("_get_delete_filter_cmd: %s", tc_cmd)
        return tc_cmd.split()

    def _delete_class_filter(self, ip_wrapper, minor_id, devs,
                             fip_ip=None, mark_id=None):
        for _int_name in devs:
            # we must delete filter first
            # delete filters(filtering by u32)
            tc_cmd = self._get_delete_filter_cmd(_int_name, fip_ip, minor_id,
                                                 mark_id)
            ip_wrapper.netns.execute(tc_cmd, check_exit_code=True)
            # and then classes, which will delete the leaf qdisc
            tc_cmd = ['tc', 'class', 'delete', 'dev', _int_name,
                      'parent', '1:', 'classid', '1:%d' % minor_id]
            ip_wrapper.netns.execute(tc_cmd, check_exit_code=True)

    def _get_add_iptables_mark_cmd(self, addr, mark_id, external_ingress_mark):
        mark_id = (mark_id << l3_constant.RATE_MARK_MASK_LONGTH) + \
                  external_ingress_mark
        iptables_cmd = ("iptables -t mangle -A PREROUTING -d %(addr)s/32 -j "
                        "MARK --set-xmark 0x%(mark_id)x/%(mask)s") % {
                            "addr": addr,
                            "mark_id": mark_id,
                            "mask": "0xffffffff"}
        LOG.debug("_get_add_iptables_mark_cmd: %s", iptables_cmd)
        return iptables_cmd.split()

    def _get_delete_iptables_mark_cmd(self, addr, mark_id,
                                      external_ingress_mark):
        mark_id = (mark_id << l3_constant.RATE_MARK_MASK_LONGTH) + \
                  external_ingress_mark
        iptables_cmd = ("iptables -t mangle -D PREROUTING -d %(addr)s/32 -j "
                        "MARK --set-xmark 0x%(mark_id)x/"
                        "%(mask)s") % {"addr": addr,
                                       "mark_id": mark_id,
                                       "mask": "0xffffffff"}
        LOG.debug("_get_delete_iptables_mark_cmd: %s", iptables_cmd)
        return iptables_cmd.split()

    def _get_check_iptables_mark_cmd(self, addr, mark_id,
                                     external_ingress_mark):
        mark_id = (mark_id << l3_constant.RATE_MARK_MASK_LONGTH) + \
                  external_ingress_mark
        iptables_cmd = ("iptables -t mangle -C PREROUTING -d %(addr)s/32 -j "
                        "MARK --set-xmark 0x%(mark_id)x/"
                        "%(mask)s") % {"addr": addr,
                                       "mark_id": mark_id,
                                       "mask": "0xffffffff"}
        LOG.debug("_get_check_iptables_mark_cmd: %s", iptables_cmd)
        return iptables_cmd.split()

    def _add_mark_filter(self, ri, ip_wrapper, tc_class_id, mark_id,
                         rate_limit, inner_interfaces, fip_ip):
        if not inner_interfaces:
            return
        # add mark config for floating ip down-flows
        try:
            iptables_cmd = self._get_check_iptables_mark_cmd(
                fip_ip, mark_id, EXTERNAL_INGRESS_MARK)
            ip_wrapper.netns.execute(iptables_cmd, check_exit_code=True)
        except RuntimeError:
            # no iptables rule, add new one
            iptables_cmd = self._get_add_iptables_mark_cmd(
                fip_ip, mark_id, EXTERNAL_INGRESS_MARK)
            ip_wrapper.netns.execute(iptables_cmd, check_exit_code=True)
        # add tc rule config for inner interface(s)
        for _int_name in inner_interfaces:
            if not _int_name:
                continue
            if not self._check_root_htb_exist(ip_wrapper, _int_name):
                self._create_ratelimit_qdisc(ip_wrapper, ri, _int_name)
        self._add_class_filter(ip_wrapper, tc_class_id, inner_interfaces,
                               rate_limit, fip_ip, mark_id)

    def _delete_mark_filter(self, ip_wrapper, tc_class_id, mark_id,
                            inner_interfaces, fip_ip):
        # delete mark config for floating ip down-flows
        iptables_cmd = self._get_delete_iptables_mark_cmd(
            fip_ip, mark_id, EXTERNAL_INGRESS_MARK)
        ip_wrapper.netns.execute(iptables_cmd, check_exit_code=True)
        # delete tc rule config for inner interface(s)
        self._delete_class_filter(ip_wrapper, tc_class_id, inner_interfaces,
                                  fip_ip, mark_id)
